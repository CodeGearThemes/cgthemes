<?php

//silence is golden